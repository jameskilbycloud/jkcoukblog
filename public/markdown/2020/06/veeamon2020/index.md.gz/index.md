---
title: "VeeamON 2020: Highlights From Veeam’s Virtual Conference"
description: "As everyone knows by now the world has changed possibly forever. Due to Covid19 working from home has become the new normal."
date: 2020-06-18T14:42:45+00:00
modified: 2026-06-01T21:58:29+00:00
author: James Kilby
categories:
  - Veeam
  - VMware
  - AWS
  - Homelab
tags:
  - #Veeam
  - #VeeamON
url: https://jameskilby.co.uk/2020/06/veeamon2020/
image: https://jameskilby.co.uk/wp-content/uploads/2020/06/veeam-logo-new-large-1934042827.png
---

![](https://jameskilby.co.uk/wp-content/uploads/2020/06/veeam-logo-new-large-1934042827.png)

[Veeam](https://jameskilby.co.uk/category/veeam/)

# VeeamON 2020: Highlights From Veeam’s Virtual Conference

By[James](https://jameskilby.co.uk) June 18, 2020June 1, 2026 • 📖1 min read(272 words)

📅 **Published:** June 18, 2020• **Updated:** June 01, 2026

As everyone knows by now, the world has changed, possibly forever. Due to Covid-19, working from home has become the new normal. We are lucky in the IT world that this has been fairly straightforward for most of us. We are privileged in that it’s possible for us to continue indefinitely. Organisations still need to move forward, to progress and adapt into the new normal.

In the words of Charles Darwin “ _It is not the strongest of the species that survives, nor the most intelligent that survives. It is the one that is most adaptable to change.”_

With that most (if not all IT conferences have been postponed or gone online) Veeam’s annual conference VeeamON is no exception and now it’s here!!

As a [Veeam Vanguard](https://www.veeam.com/vanguard.html) I was privileged to be given an early briefing on some of the announcements. These are summarised below but for all the details make sure you sign up and view some of the great sessions…

If you haven’t managed to sign up you still can [here.](https://www.veeam.com/veeamon)

## Headline Announcements

  * ### Veeam Backup for Office 365 v5

– Microsoft Teams backup

– Modern Authentication

  * ### Veeam Backup for AWS v2

– Snapshot Replication

– Hybrid Cloud

  * ### Veeam Availability Orchestrator v3

– Fast recovery using NetApp Snapshots

– DR Pack purchase options

  * ### Veeam Availability Suite v11

-Continuous Data Protection.

-Object Storage Enhancements – Capacity Tier now supporting Google Cloud Object Storage

-New Archive Tier- Supporting AWS S3 Glacier

-Instant Recovery improvements – Instant NAS & Instant Database recovery.

Last but not least, a feature that I have been asking about for over 3 years.

Yes Veeam Backup Agent for **MAC**

## 📚 Related Posts

  * [Lab Update &#8211; Desired Workloads](https://jameskilby.co.uk/2022/01/lab-update-part-5-desired-workloads/)
  * [Monitoring VMware Cloud on AWS: Tools &#038; Approaches (Part 1)](https://jameskilby.co.uk/2019/12/monitoring-vmc-part-1/)

## Similar Posts

  * [ ![Monitoring VMware Cloud on AWS: Tools & Approaches \(Part 1\)](https://jameskilby.co.uk/wp-content/uploads/2026/03/VMConAWS.png.webp) ](https://jameskilby.co.uk/2019/12/monitoring-vmc-part-1/)

[VMware](https://jameskilby.co.uk/category/vmware/) | [AWS](https://jameskilby.co.uk/category/aws/) | [Veeam](https://jameskilby.co.uk/category/veeam/)

### [Monitoring VMware Cloud on AWS: Tools & Approaches (Part 1)](https://jameskilby.co.uk/2019/12/monitoring-vmc-part-1/)

By[James](https://jameskilby.co.uk) December 17, 2019June 1, 2026

As previously mentioned I have been working a lot with VMware Cloud on AWS and one of the questions that often crops up is around an approach to monitoring.

  * [Homelab](https://jameskilby.co.uk/category/homelab/) | [Veeam](https://jameskilby.co.uk/category/veeam/) | [VMware](https://jameskilby.co.uk/category/vmware/)

### [Lab Update – Desired Workloads](https://jameskilby.co.uk/2022/01/lab-update-part-5-desired-workloads/)

By[James](https://jameskilby.co.uk) January 6, 2022June 1, 2026

My lab is always undergoing change. Partially as I want to try new things or new ways of doing things.