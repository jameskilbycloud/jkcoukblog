---
title: "Free Octopus Agile Battery & Solar Calculator: 5 Batteries Tested"
description: "I am quite a heavy consumer of electricity at home."
date: 2026-03-09T23:39:37+00:00
modified: 2026-07-11T13:21:16+00:00
author: James Kilby
categories:
  - Artificial Intelligence
  - Automation
  - Docker
  - Homelab
  - Github
  - Ansible
tags:
  - #Energy
  - #Octopus
  - #Smart Home
url: https://jameskilby.co.uk/2026/03/octopus-agile-battery-solar-calculator/
image: https://jameskilby.co.uk/wp-content/uploads/2026/03/Octopus-Energy-logo.jpg
---

![](https://jameskilby.co.uk/wp-content/uploads/2026/03/Octopus-Energy-logo.jpg)

[Artificial Intelligence](https://jameskilby.co.uk/category/artificial-intelligence/) | [Automation](https://jameskilby.co.uk/category/automation/)

# Free Octopus Agile Battery & Solar Calculator: 5 Batteries Tested

By[James](https://jameskilby.co.uk) March 9, 2026 · Updated July 11, 2026 • 📖5 min read(982 words)

I am quite a heavy consumer of electricity at home. This is primarily driven by my [lab](https://jameskilby.co.uk/lab/) but having a young son and two golden retrievers means more washing and drying. As a result I am always looking to try and reduce the electrical costs as it’s not cheap in the UK.

## Table of Contents

## Problem

Sadly my roof isn’t an ideal candidate for solar panels as the south facing part isn’t huge and has some shade, therefore I was looking at other options. I have been an Octopus Energy customer for a number of years. They have become one of the larger suppliers in the UK by offering a wide range of interesting tariffs and good customer support. I am on the “Agile Tariff” which means the price of electricity that I pay varies widely with the price changing every 30 minutes. Despite having some expensive time periods I generally come out ahead. (I am £178 better off than a tracker tariff over the last 4 months)

I have often wondered if I can make a household battery make financial sense. A lot of the public calculators didn’t really give me the level of information I needed. Therefore I decided to build this Octopus Agile battery calculator. Disclaimer: all of the coding for this project was done by [Claude](http://Claude.ai) — I can’t take any credit for it and for legal reasons double check the maths.

Below is the typical profile taken from today’s rates. Although the price changes based on demand and generation, typically windy and sunny days are the best. The typical cost profile follows this shape. Generally cheaper electricity most of the day and an expensive period between 4 and 7pm. At the time of writing the Middle East conflict has just started so the prices are higher than typical and the range between the lower and higher rate is narrower than usual.

![Agile Rate Profile](https://jameskilby.co.uk/wp-content/uploads/2026/03/Screenshot-2026-03-07-at-07.30.35-1024x713.png)

## Code

If you want to skip reading and jump straight to the code on [Github](https://github.com/jameskilbynet/AgileBatteryPredicter)

You need Python 3.8 and requests module and to add your Octopus API key to the .env file and then run the script. To get your API key just head to your Octopus account dashboard and open [**Developer settings**.](https://octopus.energy/dashboard/new/accounts/personal-details) When you run the script it will connect to the Octopus Kraken system and pull your historic usage and pricing data in 30-minute chunks. Once it has done this it will generate an HTML file called octopus_battery_report.html next to the python script for easy consumption.

You can also execute the code as a one liner:
    
    
    python3 octopus_battery_analysis.py --api-key sk_live_yourkey

📋 Copy

I have also included a diagnostic script in the repo for troubleshooting API issues octopus_diagnose.py

## Report Overview

I have built an example report that can be seen [here](https://jameskilbynet.github.io/AgileBatteryPredicter/example_report.html). Below is the extract from my usage.

### Usage Summary

![Agile Usage Summary](https://jameskilby.co.uk/wp-content/uploads/2026/03/Agile-usage-Summary-1024x247.png)

This is my usage report, and as can be seen I used 9,615kWh over the last year. For someone with gas heating and no electric cars this is quite high. I could also see this usage increasing. It also shows I had 164 hours at 0 cost or where Octopus paid me a small amount to use energy. The report then goes into a bit more consumption detail which is fairly self-explanatory.

### Agile Rate Distribution

![Agile Rate Distribution](https://jameskilby.co.uk/wp-content/uploads/2026/03/Agile-Rate-Distribution-1024x347.png)

The distribution is important to understand so we can see if we can push our usage to the left with a battery. 

The report then goes on to make battery recommendations based on the data with multiple charging strategies. The default strategy is a very simple one: we charge the battery if the charge is ≤10.0p and discharge ≥20.0p

### Battery Recommendation 

The report has details of five of the most common batteries in the UK. Powerwall 2, GivEnergy 9.5kWh, GivEnergy 13.5kWh, Sonnen 10kWh, Pylontech 7.4kWh. They all have different capacities and an estimated install cost is also assumed. It then calculates what savings could be achieved with each of these setups with either the default charging strategy or an optimised one.

Based on my usage the payback is never and the 15yr return on investment is very negative. This was disappointing. 

![Battery Recommendation](https://jameskilby.co.uk/wp-content/uploads/2026/03/BatteryRecomendation--1024x447.png)

### What If Calculator

I decided to see if I could improve by simulating some what-if scenarios so I added a slider into the report to take account of the cost of the battery system reducing and the price of electricity increasing. Unfortunately for my use case even if the price of batteries halves and the price of electricity doubles it still doesn’t make sense for me to install a battery.

### Solar

OK so what if I was to add solar to the mix? This brings another factor to consider as effectively it leads to three strategies, Solar only, Battery only or Solar and Battery. The report will showcase some typical solar installs and calculate the solar generation where the energy would be consumed by my home first and then being exported. It will model several typical solar setups 3, 4 and 6kW and ultimately recommend the most cost effective setup. I was surprised by the answer to this where a 4kW solar system without a battery is what is ultimately recommended. However this still looks like a poor investment for me personally.

![Best Solar and Battery Combination](https://jameskilby.co.uk/wp-content/uploads/2026/03/Best-Combination-1024x375.png)

#### SEG – Smart Export Guarantee

The calculator will also include earnings for any unused solar energy. This is an important factor in the calculations. 

## Conclusion

For my current usage neither a battery nor solar panels make a good investment however, I will be reviewing this periodically as the benefits and the price of both solar and battery have changed dramatically in the last couple of years. Hopefully you have a better output from the calculator.

I am also incredibly impressed with Claude’s ability to build this with limited prompting from me. The results look interesting although the script has gone through limited testing due to me only having access to two accounts with Octopus.

## 📚 Related Posts

  * [My Self-Hosted AI Stack: Infrastructure Deep Dive (Part 2)](https://jameskilby.co.uk/2026/04/my-self-hosted-ai-stack-infrastructure-deep-dive-part-2/)
  * [My Self-Hosted AI Stack: Architecture Overview (Part 1)](https://jameskilby.co.uk/2026/03/my-self-hosted-ai-stack-a-technical-deep-dive/)
  * [Automating vSphere Golden Images with Packer and GitHub Actions](https://jameskilby.co.uk/2026/04/packer-vsphere-golden-images/)

## Similar Posts

  * [ ![How I Migrated from Pocket to Hoarder with AI Integration](https://jameskilby.co.uk/wp-content/uploads/2025/01/Screenshot-2025-01-29-at-23.30.47-768x411.png) ](https://jameskilby.co.uk/2025/01/how-i-migrated-from-pocket-to-hoarder-and-introduced-some-ai-along-the-way/)

[Artificial Intelligence](https://jameskilby.co.uk/category/artificial-intelligence/) | [Docker](https://jameskilby.co.uk/category/docker/)

### [How I Migrated from Pocket to Hoarder with AI Integration](https://jameskilby.co.uk/2025/01/how-i-migrated-from-pocket-to-hoarder-and-introduced-some-ai-along-the-way/)

By[James](https://jameskilby.co.uk) January 29, 2025 · Updated July 11, 2026

Update: Hoarder has now been renamed to Karakeep due to a trademark issue I’ve been on a mission recently to regain control of my data.

  * [ ![Template Deployment with Packer](https://jameskilby.co.uk/wp-content/uploads/2021/01/logo_packer.png) ](https://jameskilby.co.uk/2021/01/hashicorp-packer/)

[Automation](https://jameskilby.co.uk/category/automation/) | [Homelab](https://jameskilby.co.uk/category/homelab/)

### [Template Deployment with Packer](https://jameskilby.co.uk/2021/01/hashicorp-packer/)

By[James](https://jameskilby.co.uk) January 21, 2021 · Updated June 5, 2026

Packer is one of those tools I have heard about, and some of the cool people on Twitter that I follow have been using it for a while.

  * [ ![Automating vSphere Golden Images with Packer and GitHub Actions](https://jameskilby.co.uk/wp-content/uploads/2026/04/packer-github-actions-vsphere-pipeline-768x452.png) ](https://jameskilby.co.uk/2026/04/packer-vsphere-golden-images/)

[Automation](https://jameskilby.co.uk/category/automation/) | [Github](https://jameskilby.co.uk/category/github/)

### [Automating vSphere Golden Images with Packer and GitHub Actions](https://jameskilby.co.uk/2026/04/packer-vsphere-golden-images/)

By[James](https://jameskilby.co.uk) April 30, 2026 · Updated June 5, 2026

A walk-through of an automated golden-image pipeline for vSphere: HashiCorp Packer builds six Ubuntu LTS templates (22.04, 24.04, 26.04 — server and desktop) driven by three GitHub Actions workflows covering PR validation, parallel template builds, and ISO management via a self-hosted runner.

  * [ ![Wa](https://jameskilby.co.uk/wp-content/uploads/2025/04/210902461-012e7273-413a-4ec7-be44-e854347f5a21-768x180.png) ](https://jameskilby.co.uk/2025/04/warp-the-intelligent-terminal/)

[Artificial Intelligence](https://jameskilby.co.uk/category/artificial-intelligence/) | [Homelab](https://jameskilby.co.uk/category/homelab/)

### [Warp – The intelligent terminal](https://jameskilby.co.uk/2025/04/warp-the-intelligent-terminal/)

By[James](https://jameskilby.co.uk) April 11, 2025 · Updated June 1, 2026

How Warp is helping me run my homelab. 

  * [ ![vSphere Power Management Ansible Playbooks with Semaphore](https://jameskilby.co.uk/wp-content/uploads/2026/04/vsphere-power-management-ansible-768x403.png) ](https://jameskilby.co.uk/2026/04/vsphere-power-management-driven-by-ansible/)

[Ansible](https://jameskilby.co.uk/category/ansible/) | [Automation](https://jameskilby.co.uk/category/automation/)

### [Automating vSphere Power Management driven by Ansible and SemaphoreUI](https://jameskilby.co.uk/2026/04/vsphere-power-management-driven-by-ansible/)

By[James](https://jameskilby.co.uk) April 15, 2026 · Updated June 1, 2026

In this post I’ll walk through how I use vSphere Power Management driven by Ansible and SemaphoreUI to automatically reduce ESXi host electricity consumption — saving real money on my Octopus Agile tariff by toggling hosts between Low Power and Balanced policies. Introduction One of the larger costs of running my homelab is the electricity….

  * [ ![Automated VCF 9 Offline Depot architecture diagram showing Traefik reverse proxy and Nginx file server stack](https://jameskilby.co.uk/wp-content/uploads/2026/04/offlinedepot.png) ](https://jameskilby.co.uk/2026/04/automated-vcf-9-offline-depot/)

[Ansible](https://jameskilby.co.uk/category/ansible/) | [Automation](https://jameskilby.co.uk/category/automation/)

### [Automated VCF 9 Offline Depot](https://jameskilby.co.uk/2026/04/automated-vcf-9-offline-depot/)

By[James](https://jameskilby.co.uk) April 10, 2026 · Updated July 11, 2026

One Bash script turns a fresh Ubuntu VM into a VCF 9 Offline Depot: Traefik, Nginx, basic auth, and Let’s Encrypt wildcard certs via Cloudflare DNS.