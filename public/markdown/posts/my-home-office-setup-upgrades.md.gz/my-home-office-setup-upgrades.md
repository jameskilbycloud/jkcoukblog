---
title: "My Home Office Setup & Upgrades"
description: "Given the year that was 2020 and at the time of writing a distinct improvement appears a long way off I decided it was time to up my homeworking game."
date: 2021-01-05T12:17:13+00:00
modified: 2026-06-01T19:02:30+00:00
author: James Kilby
categories:
  - Personal
  - Consulting
  - Hosting
  - VMware
  - vSphere
  - Cloudflare
  - Wordpress
  - Nutanix
  - AWS
tags:
  - #Homeoffice
  - #WFH
  - #Zoom
url: https://jameskilby.co.uk/2021/01/my-home-office-setup-upgrades/
image: https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7017-scaled-1-1024x768.jpeg
---

![Img 7017 Scaled 1](https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7017-scaled-1.jpeg)

[Personal](https://jameskilby.co.uk/category/personal/) | [Consulting](https://jameskilby.co.uk/category/consulting/)

# My Home Office Setup & Upgrades

By[James](https://jameskilby.co.uk)January 5, 2021 · Updated June 1, 2026 • 📖8 min read(1,570 words)

📅 **Published:** January 05, 2021• **Updated:** June 01, 2026

Given the year that was 2020 and at the time of writing a distinct improvement appears a long way off I decided it was time to up my homeworking game. I bought a beautiful Dell 49″ monitor back in mid-2020 that has been the central focus of my home office. With this setup I always had my trusty Macbook Air shut as I have no need for any more screen estate. This caused some challenges for video calls with the ever-present Zoom/Teams as the webcam I was using was no longer available. 

I tried a few options to improve this but they were all a bit suboptimal. I decided to do a few drastic upgrades over the last month or so. This post is to show exactly what I’m running as of January 2021.

A few people have asked me exactly how I have my desk setup so this is an exhaustive list of everything on my desk, however, not everything is a recent purchase. 

I’ll start with the BOM. I have attached a link to where they can be obtained (If it’s an Amazon link it will be an affiliate link) and the price I paid. If the exact item is no longer produced the link will go to an equivalent. I won’t go into detail on every component but if you have any questions please ask.

## Bill of Materials

Item | Cost £| Link  
---|---|---  
Standing Desk| 500| [Ikea](https://www.ikea.com/gb/en/p/idasen-desk-sit-stand-brown-beige-s89280969/)  
Headphone Stand| 22.90| [Amazon](https://amzn.to/2XQYvsp)  
Laptop Stand| 19.99| [Amazon](https://amzn.to/2XPNVli)  
Apple Macbook Air 2018 13″| 1779| [Apple](https://www.apple.com/uk/shop/buy-mac/macbook-air)  
Apple iPad Pro 9.7″| 599.39| [Apple](https://www.apple.com/uk/shop/buy-ipad/ipad-pro)  
Apple Pencil | 99.99| [Amazon](https://amzn.to/2Kd0vYC)  
Dell 49″ Monitor| 1100| [Dell](https://www.dell.com/en-uk/shop/dell-ultrasharp-49-curved-monitor-u4919dw/apd/210-argk/monitors-monitor-accessories)  
Ergotron MX| 119.76| [Amazon](https://amzn.to/2Lz46RI)  
Elgato Ring Light| 189.95| [Amazon](https://amzn.to/38PI0mM)  
Canon EOS 5D Mk IV| 2799| [Amazon](https://amzn.to/39J1jgx)  
Canon 17-40MM F4 Lens + Hoya UV Filter| 573| [Amazon](https://amzn.to/38PI0mM)  
Blackmagic Design Atem Mini| 303| [Amazon](https://amzn.to/38PI0mM)  
Shure MV7 + Stand| 289| [Amazon](https://amzn.to/2KHOvPf)  
Anker USB-C Charger| 29.99| [Amazon](https://amzn.to/3iE2LoC)  
Amazon Echo Show 5| 29.99| [Amazon](https://amzn.to/2Kd0vYC)  
Yubikey 4| 39.99| [Amazon](https://amzn.to/3ifPHp7)  
Beats Solo Pro*| 169.99| [Amazon](https://amzn.to/3qwVsC2)  
Knobsound Amp| 41.99| [Amazon](https://amzn.to/3sByXxx)  
Assorted Cables| 100| N/A  
 **Total**|  **8306.93**|   
  
## Desk – Ikea Idasen Sit/Stand 160

The desk is the focal point of a home office and therefore it’s an important choice. I decided a while ago to go for a standing desk and I also prefer having a wide desk so I got the 1.6M wide Ikea Idasen desk and it’s awesome. I don’t stand as often as I possibly should but it’s something I do every day.

The choice of a standing desk makes everything else a bit harder as everything needs to move with the desk while remaining stable. It also means you need to be careful with cable lengths and mounting things. I have 3 cables running to the desk. A single power lead and two Cat 5e’s one for my Macbook Air and one for my Atem Mini. 

![IMG 7017 scaled 1](https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7017-scaled-1-1024x768.jpeg)Desk Setup

## Monitor – Dell UltraSharp 49 Curved U4919DW

The Monitor dominates my entire view and it’s huge, no other way to describe it. It’s the equivalent of 2×27″ Monitors sat side by side and runs in 5120 x 1440 at 60 Hz. My Mac is connected via USB-C This helps in reducing the cables on the desk. The Monitor offers a number of USB ports which offer a convenient place to plug my Yubikey as my Mac is placed out of reach. The Monitor has the typical inputs you expect and has a nice picture in picture feature that I sometimes utilise with the Atem Mini. The Atem outputs via HDMI as well as USB-C and I utilise this to check the preview output that will be viewed. 

## Monitor Arm – Ergotron MX 

The Dell Monitor does come with an included stand but it took up a large footprint on my desk. Due to the size and weight of the Dell U4919DW (the screen is 11.4 kg), it heavily limited the choice of stands that were suitable. 

I settled on the MX from Ergotron and it’s perfect. The springs did need tightening to accommodate the weight but once that was done it holds the screen where it’s set. (I slightly change the position depending on if I’m standing or sitting at the desk.)

## Camera – Canon EOS 5D MkIV

I have had a variety of Canon SLR’s over the last 14 years and the 5D is certainly the best, It is an exceptional piece of kit. It offers a number of key features that I can utilise. One of the advantages is that it has a clean HDMI output. This is fed directly into the Atem Mini. It has excellent focus capabilities using the Dual Pixel CMOS and this combined with AF subject tracking allows me to always be in focus.

![IMG 7021 scaled 1 1](https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7021-scaled-1-1-1024x768.jpeg)

The 5D also has WIFI control capabilities allowing me to both preview or amend any of the settings from an app on my iPhone. This is useful for amending the audio gain or exposure options if needed. This is a bit of a pain to do without the app so it’s a big advantage. Coupled to the front of the 5D I have a Canon 17-40 F4 L lens. I tend to have this wide open to throw the background out of focus a bit. 

A sample image is below.

![Screenshot 2021 01 15 at 00.09.45](https://jameskilby.co.uk/wp-content/uploads/2023/05/Screenshot-2021-01-15-at-00.09.45-1024x567.png)

## Lighting – Elgato Ring Light

The Canon 5D is mounted in the centre of an Elgato Ring light. This is clipped to the back of the centre of my desk. I have it set to 5700K in the above picture which seems to be the colour temperature that’s most neutral. A picture of what it looks like from my point of view is below.

![IMG 7021 scaled 1](https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7021-scaled-1-1024x768.jpeg)

## Sound – Shure MV7

![IMG 7023 scaled 1](https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7023-scaled-1-1024x768.jpeg)

Shure are probably the most famous name in microphones, the MV7 is a slight departure from the professional-grade microphones like the SM58 that they are famous for. This is because the MV7 is a dual output mic with a USB-C as well as a standard XLR output. It’s also capable of outputting to both at the same time. This gives me the flexibility of recording directly to my Macbook if needed or my preferred route into the 5D. This is preferred as it removes any possible sync issues between audio and video plus has the added benefit of being capable of being recorded within the 5D as well as on my Macbook via the ATEM.

## Video – Blackmagic Design Atem Mini

![IMG 7022 scaled 1](https://jameskilby.co.uk/wp-content/uploads/2023/05/IMG_7022-scaled-1-1024x768.jpeg)

The ATEM Mini is the centrepiece of the media part of my setup. It controls all of the inputs and outputs. Although it’s the most basic in the ATEM range it’s got a pretty advanced feature set. It has 4 HDMI inputs and I typically use 3 of these. They are for the 5D, Macbook Air and iPad Pro. The mixer then has two distinct outputs. One is HDMI and the other is USB-C which is plugged back into my Mac. The connection into the Mac signals as a USB Webcam. This makes it easy to use in any application. It also does a very neat trick that John Nicholson pointed out to me. As well as pretending to be a webcam it also shows up as an external monitor. Where this becomes insanely useful is for apps like PowerPoint. Powerpoint detects the second monitor and presents the full screen to the Mini that the audience see. But I retain the presenter view on-screen with presenter notes timings etc. 

![Screenshot 2021 01 15 at 02.06.47](https://jameskilby.co.uk/wp-content/uploads/2023/05/Screenshot-2021-01-15-at-02.06.47.png)

The ATEM also has upstream and downstream capabilities, allowing for the mixing of multiple video screens.

The example here is taking this presentation being run from my iPad and overlaying it over the Camera input. I will do a separate post with some info on how it was put together and add some audio.

<https://youtu.be/feMFZbnH00w>

If you have read this far and you have been paying attention you may have noticed that a Mac Mini has appeared on my desk. 

Yes, I snuck in one of the new M1 arm based Mac’s. I must say I have been blown away by the performance of it. I decided to go for the 8GB of Ram with 512GB disk option after watching a number of YouTube videos. So far it has been able to handle everything I have been throwing at it with ease.

I will do a separate post concentrating on the M1 once I have lived with it for a bit longer. One feature that appears not to work is the ATEM mini dual display described above. Further investigation is required.

## Future purchases

### Elgato Streamdeck

A lot of people have these and it’s something I would strongly consider. I purchased the software version and run this on my iPad Pro. I think this was a sensible thing to do to see how it can be used with the various integrations and although it’s a simple concept I have been very happy with it and will likely upgrade to a hardware version at some point.

### Herman Miller Aeron

When travel was a thing I was lucky enough to visit a number of customers in the high tech/financial industry. This allowed me to “sample” a number of quality seats. The best of which has to be the Aeron. It has an amazing reputation and a large price tag to go with it. So, for now, it’s just on the wish list.

*The Beats Solo’s were a gift as part of the Veeam Vanguard Program. I didn’t purchase these with my own money.

## 📚 Related Posts

  * [Analytics in a privacy focused world](https://jameskilby.co.uk/2023/11/analytics-in-a-privacy-focused-world/)
  * [Advanced Deploy VMware vSphere 7.x 3V0-22.21N](https://jameskilby.co.uk/2023/11/advanced-deploy-vmware-vsphere-7-x-3v0-22-21n/)
  * [VMware &#8211; Going out with a Bang!](https://jameskilby.co.uk/2023/10/going-out-with-a-bang/)

## Similar Posts

  * [![Analytics in a privacy focused world](https://jameskilby.co.uk/wp-content/uploads/2023/11/plausible-analytics-icon-top.png)](https://jameskilby.co.uk/2023/11/analytics-in-a-privacy-focused-world/)

[Hosting](https://jameskilby.co.uk/category/hosting/) | [Personal](https://jameskilby.co.uk/category/personal/)

### [Analytics in a privacy focused world](https://jameskilby.co.uk/2023/11/analytics-in-a-privacy-focused-world/)

By[James](https://jameskilby.co.uk)November 10, 2023 · Updated June 1, 2026

I recently helped my friend Dean Lewis @veducate with some hosting issues. As part of the testing of this he kindly gave me a login to his WordPress instance.

  * [![Advanced Deploy VMware vSphere 7.x 3V0-22.21N](https://jameskilby.co.uk/wp-content/uploads/2023/11/image.png)](https://jameskilby.co.uk/2023/11/advanced-deploy-vmware-vsphere-7-x-3v0-22-21n/)

[VMware](https://jameskilby.co.uk/category/vmware/) | [Personal](https://jameskilby.co.uk/category/personal/) | [vSphere](https://jameskilby.co.uk/category/vsphere/)

### [Advanced Deploy VMware vSphere 7.x 3V0-22.21N](https://jameskilby.co.uk/2023/11/advanced-deploy-vmware-vsphere-7-x-3v0-22-21n/)

By[James](https://jameskilby.co.uk)November 10, 2023 · Updated June 1, 2026

Yesterday I sat and passed the above exam. It had been on my todo list for a good number of years. With the current pause in the Broadcom VMware takeover deal.

  * [![Hosting This Blog on Cloudflare Workers: Why & How I Did It](https://jameskilby.co.uk/wp-content/uploads/2020/06/iu-2-768x229.png)](https://jameskilby.co.uk/2022/01/web-development/)

[Hosting](https://jameskilby.co.uk/category/hosting/) | [Cloudflare](https://jameskilby.co.uk/category/cloudflare/) | [Personal](https://jameskilby.co.uk/category/personal/) | [Wordpress](https://jameskilby.co.uk/category/wordpress/)

### [Hosting This Blog on Cloudflare Workers: Why & How I Did It](https://jameskilby.co.uk/2022/01/web-development/)

By[James](https://jameskilby.co.uk)January 4, 2022 · Updated May 25, 2026

A while ago I started messing with Cloudflare Workers. I have now moved this site permanently over to them.

  * [![Passing the Nutanix NCP Exam: Free Training & My Experience](https://jameskilby.co.uk/wp-content/uploads/2020/07/nutanix-logo-HI-REZ_reverse-w-carrier-768x196.jpg)](https://jameskilby.co.uk/2020/07/nutanix-ncp/)

[Nutanix](https://jameskilby.co.uk/category/nutanix/) | [Personal](https://jameskilby.co.uk/category/personal/)

### [Passing the Nutanix NCP Exam: Free Training & My Experience](https://jameskilby.co.uk/2020/07/nutanix-ncp/)

By[James](https://jameskilby.co.uk)July 2, 2020 · Updated May 31, 2026

I saw a tweet a couple of weeks ago mentioning that Nutanix were offering a free go at the Nutanix Certified Professional exam.

  * [![What’s In My Tech Bag? Everyday Carry for IT Consultants](https://jameskilby.co.uk/wp-content/uploads/2019/01/Picture1-768x498.png)](https://jameskilby.co.uk/2019/01/whats-in-my-backpack/)

[Consulting](https://jameskilby.co.uk/category/consulting/)

### [What’s In My Tech Bag? Everyday Carry for IT Consultants](https://jameskilby.co.uk/2019/01/whats-in-my-backpack/)

By[James](https://jameskilby.co.uk)January 10, 2019 · Updated June 1, 2026

I have seen a few posts online recently about the tools and technology people use on a day to day basis.

  * [![AWS Solution Architect – Associate](https://jameskilby.co.uk/wp-content/uploads/2018/05/AmazonWebservices_Logo.svg_-768x307.png)](https://jameskilby.co.uk/2019/12/aws-solution-architect-associate/)

[AWS](https://jameskilby.co.uk/category/aws/) | [Personal](https://jameskilby.co.uk/category/personal/)

### [AWS Solution Architect – Associate](https://jameskilby.co.uk/2019/12/aws-solution-architect-associate/)

By[James](https://jameskilby.co.uk)December 16, 2019 · Updated May 31, 2026

I renewed my AWS Solution Architect certification.