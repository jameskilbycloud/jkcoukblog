---
title: "Changelog - James Kilby"
description: "Site improvements, deployments, and performance metrics for James Kilby's technical blog."
author: James Kilby
url: https://jameskilby.co.uk/changelog/
---

[← Back to Home](https://jameskilby.co.uk/)

# 📋 Changelog

Site improvements, deployments, and performance metrics

[ ![Quality Checks workflow status](https://github.com/jameskilbynet/jkcoukblog/actions/workflows/quality-checks.yml/badge.svg) ](https://github.com/jameskilbynet/jkcoukblog/actions/workflows/quality-checks.yml)

### Total Deployments

1105

Git commits

### Repository Age

310

Days active

### Contributors

5

Active contributors

### Last Deployment

2026-08-09

04:35:11

## 🚀 Lighthouse Performance Scores

Last checked: 2026-08-09 04:35:10 UTC

93 

Performance

96 

Accessibility

93 

Best Practices

100 

SEO

## Recent Changes

2026-08-09 3b7305bOther

chore(lighthouse): record scores P93/A96/BP93/S100

2026-08-09 0402897Other

chore(lighthouse): record scores P93/A96/BP93/S100

  

2026-08-08 e2372b1Other

chore(lighthouse): record scores P92/A96/BP93/S100

  

2026-08-09 ee02312Other

feat: assert output quality in CI and report it to Slack (#147)

The 2026-08-08 incident shipped 172/254 pages over the Lighthouse stylesheet

  

2026-08-08 c61216aFix

fix: resolve absolute same-site hrefs before the stylesheet disk lookup (#146)

* fix: instrument WP stylesheet inlining and cover extracted inline CSS

2026-08-08 3e27c27Fix

fix: instrument WP stylesheet inlining and cover extracted inline CSS (#145)

The 2026-08-08 deploy left 172 of 254 pages over the Lighthouse

2026-08-08 b56a057Improvement

feat: adapt asset pipeline to WP-Optimize minify being disabled (#144)

WP-Optimize's minify feature was disabled because its cache path embedded a

2026-08-08 994b979Other

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-08-07 d67380eOther

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-08-06 c8bb151Other

chore(lighthouse): record scores P92/A96/BP100/S100

2026-08-06 902037eOther

chore(deps): Bump pillow-avif-plugin from 1.5.5 to 1.6.0 (#142)

Bumps [pillow-avif-plugin](https://github.com/fdintino/pillow-avif-plugin) from 1.5.5 to 1.6.0.

2026-08-06 ced9fbaOther

chore(deps-dev): Bump ruff from 0.15.22 to 0.16.1 (#143)

Bumps [ruff](https://github.com/astral-sh/ruff) from 0.15.22 to 0.16.1.

  

2026-08-05 d1ecf45Other

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-08-04 913f7feOther

chore(lighthouse): record scores P93/A96/BP100/S100

  

2026-08-03 bdeadbfOther

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-08-02 ab1beebOther

chore(lighthouse): record scores P96/A96/BP100/S100

  

2026-08-01 dc79340Other

chore(lighthouse): record scores P94/A96/BP100/S100

  

2026-07-31 006d41aOther

chore(lighthouse): record scores P91/A96/BP100/S100

  

2026-07-30 c23f764Other

chore(lighthouse): record scores P93/A96/BP100/S100

  

2026-07-29 501e4c6Other

chore(lighthouse): record scores P93/A96/BP100/S100

  

2026-07-28 edee49fFix

fix(worker+generator): GSC 404 sweep — easy wins + tag pagination

Sweep of the URLs GSC surfaced as 404s that today's flat-slug fix didn't

2026-07-28 4f9ecddOther

chore(lighthouse): record scores P92/A96/BP100/S100

2026-07-28 544b76bFix

fix(worker): move flat-slug legacy redirects out of _redirects into worker

Cloudflare Pages' free plan silently drops any static redirect past rule

2026-07-28 8b969d7Other

chore(lighthouse): record scores P91/A96/BP100/S100

  

2026-07-27 92d1621Other

chore(lighthouse): record scores P93/A96/BP100/S100

  

2026-07-26 3b694dcOther

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-07-25 4ce3720Other

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-07-24 588b77cOther

chore(lighthouse): record scores P92/A96/BP100/S100

  

2026-07-23 6c3d9e7Other

chore(lighthouse): record scores P89/A96/BP100/S100

  

2026-07-22 44d3d4aOther

chore(deps): Bump actions/setup-python from 6 to 7 (#138)

Bumps [actions/setup-python](https://github.com/actions/setup-python) from 6 to 7.

Page generated: 2026-08-09 06:42:03 UTC  
Changelog powered by Git history and Lighthouse CI